<?php $__env->startSection('title', ($article->meta_title ?: $article->title) . ' — Conserve India'); ?>
<?php $__env->startSection('description', $article->meta_description ?: ($article->summary ?: Str::limit(strip_tags($article->content), 155))); ?>

<?php $__env->startSection('content'); ?>
  <!-- Editorial Page Header -->
  <header class="ed-page-header">
    <div class="container px-lg-4">
      <nav class="ed-breadcrumbs" aria-label="Breadcrumb">
        <a href="<?php echo e(url('/')); ?>">Home</a> <span>/</span> <a href="<?php echo e(url('/green-stories')); ?>">Green Stories</a> <span>/</span> <?php echo e(Str::limit($article->title, 40)); ?>

      </nav>
      <span class="ed-section-tag"><?php echo e($article->category ?? 'CIRCULAR ECONOMY & RESEARCH'); ?></span>
      <h1 class="ed-page-title" style="max-width: 900px;"><?php echo e($article->title); ?></h1>
      <div class="d-flex align-items-center gap-3 text-muted small mt-3 flex-wrap">
        <span><i class="bi bi-calendar3 text-success me-1"></i> <?php echo e($article->published_date ? \Carbon\Carbon::parse($article->published_date)->format('F d, Y') : $article->created_at->format('F d, Y')); ?></span>
        <span>&bull;</span>
        <span><i class="bi bi-person-fill text-success me-1"></i> Conserve India Editorial Desk</span>
        <span>&bull;</span>
        <span><i class="bi bi-clock me-1"></i> 5 Min Read</span>
      </div>
    </div>
  </header>

  <!-- Article Body Section -->
  <article class="ed-content-section" style="background: #fff; padding: 60px 0 90px;">
    <div class="container px-lg-4">
      <div class="row g-5 justify-content-center">
        
        <div class="col-lg-8">
          <?php if($article->image): ?>
            <div class="ed-media-box mb-4" style="aspect-ratio: 16 / 9; border-radius: 14px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.06);">
              <img src="<?php echo e(str_starts_with($article->image, 'http') ? $article->image : asset('website/' . $article->image)); ?>" alt="<?php echo e($article->title); ?>" class="ed-media-img" style="object-fit: cover; width: 100%; height: 100%;">
            </div>
          <?php endif; ?>

          <?php if($article->summary): ?>
            <div class="p-4 rounded-3 mb-4" style="background: #fbfaf6; border-left: 4px solid var(--primary-forest); font-size: 16.5px; line-height: 1.7; color: var(--text-primary); font-style: italic;">
              <?php echo e($article->summary); ?>

            </div>
          <?php endif; ?>

          <div class="article-rich-content" style="font-size: 16px; line-height: 1.85; color: #374151;">
            <?php if(strip_tags($article->content) != $article->content): ?>
              <?php echo $article->content; ?>

            <?php else: ?>
              <?php echo nl2br(e($article->content)); ?>

            <?php endif; ?>
          </div>

          <!-- Share Strip -->
          <div class="pt-4 mt-5 border-top border-light-subtle d-flex flex-wrap align-items-center justify-content-between gap-3">
            <div class="d-flex align-items-center gap-2">
              <span class="fw-bold small text-muted text-uppercase" style="letter-spacing: 1px;">Share this story:</span>
              <a href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo e(urlencode(url()->current())); ?>" target="_blank" rel="noopener noreferrer" class="btn btn-sm btn-outline-secondary rounded-circle" style="width: 36px; height: 36px; display: inline-flex; align-items: center; justify-content: center;" title="Share on LinkedIn">
                <i class="bi bi-linkedin"></i>
              </a>
              <a href="https://twitter.com/intent/tweet?text=<?php echo e(urlencode($article->title)); ?>&url=<?php echo e(urlencode(url()->current())); ?>" target="_blank" rel="noopener noreferrer" class="btn btn-sm btn-outline-secondary rounded-circle" style="width: 36px; height: 36px; display: inline-flex; align-items: center; justify-content: center;" title="Share on X">
                <i class="bi bi-twitter-x"></i>
              </a>
              <a href="https://api.whatsapp.com/send?text=<?php echo e(urlencode($article->title . ' ' . url()->current())); ?>" target="_blank" rel="noopener noreferrer" class="btn btn-sm btn-outline-secondary rounded-circle" style="width: 36px; height: 36px; display: inline-flex; align-items: center; justify-content: center;" title="Share on WhatsApp">
                <i class="bi bi-whatsapp text-success"></i>
              </a>
              <button type="button" class="btn btn-sm btn-outline-secondary rounded-circle" style="width: 36px; height: 36px; display: inline-flex; align-items: center; justify-content: center;" title="Copy Link" onclick="navigator.clipboard.writeText(window.location.href); alert('Article link copied to clipboard!');">
                <i class="bi bi-link-45deg"></i>
              </button>
            </div>

            <a href="<?php echo e(url('/green-stories')); ?>" class="ed-link-arrow">
              &larr; Back to All Green Stories
            </a>
          </div>
        </div>

        <!-- Sidebar -->
        <div class="col-lg-4">
          <div class="position-sticky" style="top: 100px;">
            
            <!-- Quick About Conserve Box -->
            <div class="p-4 rounded-3 border border-light-subtle mb-4" style="background: #fbfaf6;">
              <span class="ed-section-tag mb-2">ABOUT CONSERVE INDIA</span>
              <h4 class="h6 fw-bold mb-2" style="color: var(--primary-forest);">Renewing From People to Planet</h4>
              <p class="text-secondary small mb-3" style="line-height: 1.6;">
                Pioneering patented plastic recycling and dignified livelihoods for India's informal waste collectors and refugee women since 1997.
              </p>
              <a href="<?php echo e(url('/about-us')); ?>" class="ed-btn-outline w-100 text-center py-2">
                Discover Our Heritage &rarr;
              </a>
            </div>

            <!-- Recent Stories -->
            <?php if($recentArticles->isNotEmpty()): ?>
              <div class="p-4 rounded-3 border border-light-subtle" style="background: #ffffff;">
                <h4 class="h6 fw-bold mb-3" style="color: var(--primary-forest); text-transform: uppercase; letter-spacing: 1px;">Recent Field Stories</h4>
                <div class="d-flex flex-column gap-3">
                  <?php $__currentLoopData = $recentArticles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="d-flex gap-3 align-items-center">
                      <?php if($recent->image): ?>
                        <img src="<?php echo e(str_starts_with($recent->image, 'http') ? $recent->image : asset('website/' . $recent->image)); ?>" alt="<?php echo e($recent->title); ?>" class="rounded" style="width: 64px; height: 64px; object-fit: cover; flex-shrink: 0;">
                      <?php endif; ?>
                      <div>
                        <span class="badge bg-light text-success border small mb-1"><?php echo e($recent->category ?? 'Story'); ?></span>
                        <a href="<?php echo e(route('story.detail', $recent->slug)); ?>" class="text-decoration-none d-block fw-semibold" style="font-size: 13.5px; color: var(--primary-forest); line-height: 1.4;">
                          <?php echo e(Str::limit($recent->title, 55)); ?>

                        </a>
                      </div>
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              </div>
            <?php endif; ?>

          </div>
        </div>

      </div>
    </div>
  </article>

  <!-- CTA Banner -->
  <section class="ed-content-section-muted" style="border-top: 1px solid var(--border-subtle);">
    <div class="container px-lg-4 text-center">
      <span class="ed-section-tag">COLLABORATE WITH US</span>
      <h2 class="ed-section-title mb-3">Interested in Our Research or Upcycled Products?</h2>
      <p class="ed-section-desc mx-auto mb-4">
        We partner with corporations, universities, and conscious global brands to advance circular economy models.
      </p>
      <div class="d-flex justify-content-center gap-3 flex-wrap">
        <a href="<?php echo e(url('/contact-us')); ?>" class="btn-primary-forest px-4 py-2">
          Contact Our Team &rarr;
        </a>
        <a href="<?php echo e(url('/services')); ?>" class="ed-btn-outline px-4 py-2">
          Explore Services
        </a>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('website.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\laravel_project\conserveindia\resources\views\website\story-detail.blade.php ENDPATH**/ ?>