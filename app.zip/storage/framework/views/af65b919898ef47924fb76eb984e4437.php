<?php $__env->startSection('title', 'Add New Slide'); ?>
<?php $__env->startSection('page_heading', 'Add Hero Slide'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
  <div class="col-lg-9">
    <div class="admin-card">
      <div class="admin-card-header">
        <h6 class="fw-bold mb-0">Create Slide</h6>
        <a href="<?php echo e(route('admin.sliders.index')); ?>" class="btn btn-sm btn-outline-secondary">Back to List</a>
      </div>
      <div class="admin-card-body">
        <form action="<?php echo e(route('admin.sliders.store')); ?>" method="POST" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>

          <div class="mb-3">
            <label class="form-label small fw-semibold">Slide Headline / Title *</label>
            <input type="text" name="title" class="form-control" value="<?php echo e(old('title')); ?>" required placeholder="e.g. Turning Waste Plastic into Dignified Livelihoods">
          </div>

          <div class="row g-3 mb-3">
            <div class="col-md-6">
              <label class="form-label small fw-semibold">Category Tag</label>
              <input type="text" name="tag" class="form-control" value="<?php echo e(old('tag')); ?>" placeholder="e.g. CIRCULAR ECONOMY IN ACTION">
            </div>
            <div class="col-md-3">
              <label class="form-label small fw-semibold">Display Order</label>
              <input type="number" name="order" class="form-control" value="<?php echo e(old('order', 0)); ?>">
            </div>
            <div class="col-md-3 d-flex align-items-end">
              <div class="form-check mb-2">
                <input class="form-check-input" type="checkbox" name="is_active" id="is_active" value="1" checked>
                <label class="form-check-label small fw-semibold" for="is_active">Active on Site</label>
              </div>
            </div>
          </div>

          <div class="mb-3">
            <label class="form-label small fw-semibold">Subtitle / Paragraph Description</label>
            <textarea name="subtitle" class="form-control" rows="3" placeholder="Brief supporting narrative..."><?php echo e(old('subtitle')); ?></textarea>
          </div>

          <div class="row g-3 mb-3">
            <div class="col-md-6">
              <label class="form-label small fw-semibold">Primary Button Text</label>
              <input type="text" name="button_text" class="form-control" value="<?php echo e(old('button_text', 'Discover Our Mission')); ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label small fw-semibold">Primary Button Link</label>
              <input type="text" name="button_link" class="form-control" value="<?php echo e(old('button_link', 'our-work')); ?>">
            </div>
          </div>

          <div class="row g-3 mb-3">
            <div class="col-md-6">
              <label class="form-label small fw-semibold">Secondary Button Text</label>
              <input type="text" name="secondary_button_text" class="form-control" value="<?php echo e(old('secondary_button_text')); ?>" placeholder="e.g. Explore Upcycled Collections">
            </div>
            <div class="col-md-6">
              <label class="form-label small fw-semibold">Secondary Button Link</label>
              <input type="text" name="secondary_button_link" class="form-control" value="<?php echo e(old('secondary_button_link')); ?>" placeholder="e.g. services">
            </div>
          </div>

          <div class="mb-4">
            <label class="form-label small fw-semibold">Slide Background Image *</label>
            <input type="file" name="image" class="form-control" accept="image/*" required>
            <small class="text-muted">High resolution landscape image recommended (1920x1080 or 1600x900).</small>
          </div>

          <div class="text-end border-top pt-3">
            <a href="<?php echo e(route('admin.sliders.index')); ?>" class="btn btn-light border me-2">Cancel</a>
            <button type="submit" class="btn btn-admin-forest">Save Slide</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\laravel_project\conserveindia\resources\views\admin\sliders\create.blade.php ENDPATH**/ ?>