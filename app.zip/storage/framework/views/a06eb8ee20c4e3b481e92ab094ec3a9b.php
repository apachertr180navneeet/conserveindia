<?php $__env->startSection('title', 'Gallery — Conserve India | 13 Milestone Circular Projects & Artisans'); ?>
<?php $__env->startSection('description', 'Explore Conserve India\'s photo and project gallery: 13 groundbreaking initiatives from patented HRP technology to ragpicker associations and refugee empowerment.'); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Header -->
  <header class="ed-page-header">
    <div class="container px-lg-4">
      <nav class="ed-breadcrumbs" aria-label="Breadcrumb">
        <a href="<?php echo e(url('/')); ?>">Home</a> <span>/</span> Gallery
      </nav>
      <span class="ed-section-tag"><?php echo e($page->subtitle ?? 'PROJECT REPOSITORY'); ?></span>
      <h1 class="ed-page-title"><?php echo e($page->title ?? 'Gallery of Milestones & Grassroots Action'); ?></h1>
      <p class="ed-page-lead">
        <?php echo e($page->lead_text ?? 'A visual showcase of the foundational initiatives shaping our journey—from patented material discoveries to cooperative waste collectors associations and refugee ateliers.'); ?>

      </p>
      <?php if(!empty($page->content)): ?>
        <div class="mt-4 p-4 bg-white rounded-3 border border-light-subtle shadow-sm text-secondary" style="line-height: 1.8;">
          <?php echo $page->content; ?>

        </div>
      <?php endif; ?>
    </div>
  </header>

  <!-- Gallery Filter & Grid Section -->
  <section class="ed-content-section" style="background: #fff;">
    <div class="container px-lg-4">
      
      <?php
        $catCounts = [
          'all' => count($projects),
          'livelihoods' => 0,
          'patent' => 0,
          'community' => 0,
          'products' => 0,
          'youth' => 0,
        ];
        foreach ($projects as $p) {
          $c = is_array($p) ? ($p['category'] ?? 'community') : ($p->category ?? 'community');
          if (isset($catCounts[$c])) {
            $catCounts[$c]++;
          }
        }
      ?>

      <!-- Filter Bar -->
      <div class="d-flex flex-wrap justify-content-center gap-2 mb-5" id="galleryFilters">
        <button type="button" class="btn btn-sm btn-outline-success active px-3 py-2 filter-btn" data-filter="all">All Initiatives (<?php echo e($catCounts['all']); ?>)</button>
        <button type="button" class="btn btn-sm btn-outline-success px-3 py-2 filter-btn" data-filter="livelihoods">Livelihoods &amp; Artisans (<?php echo e($catCounts['livelihoods']); ?>)</button>
        <button type="button" class="btn btn-sm btn-outline-success px-3 py-2 filter-btn" data-filter="patent">Patents &amp; Material R&amp;D (<?php echo e($catCounts['patent']); ?>)</button>
        <button type="button" class="btn btn-sm btn-outline-success px-3 py-2 filter-btn" data-filter="community">Community &amp; Advocacy (<?php echo e($catCounts['community']); ?>)</button>
        <button type="button" class="btn btn-sm btn-outline-success px-3 py-2 filter-btn" data-filter="products">Brands &amp; Products (<?php echo e($catCounts['products']); ?>)</button>
        <button type="button" class="btn btn-sm btn-outline-success px-3 py-2 filter-btn" data-filter="youth">Youth Incubator (<?php echo e($catCounts['youth']); ?>)</button>
      </div>

      <!-- Projects Grid -->
      <div class="row g-4" id="galleryGrid">
        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php
            $cat = is_array($item) ? ($item['category'] ?? 'all') : ($item->category ?? 'all');
            $img = is_array($item) ? ($item['image'] ?? '') : ($item->image ?? '');
            $title = is_array($item) ? ($item['title'] ?? '') : ($item->title ?? '');
            $loc = is_array($item) ? ($item['location'] ?? 'Delhi') : ($item->meta ?? 'Delhi');
            $stat = is_array($item) ? ($item['stat'] ?? 'Initiative') : 'Conserve Initiative';
            $tag = is_array($item) ? ($item['tag'] ?? 'Project') : ($item->category ?? 'Project');
            $desc = is_array($item) ? ($item['desc'] ?? '') : ($item->short_description ?? '');
            $link = is_array($item) ? ($item['link'] ?? null) : ($item->link ?? null);
            $imgSrc = str_starts_with($img, 'http') ? $img : (str_starts_with($img, '/') ? $img : asset('website/' . $img));
          ?>
          <div class="col-md-6 col-lg-4 gallery-item" data-category="<?php echo e($cat); ?>">
            <div class="ed-work-card h-100 bg-white border border-light-subtle d-flex flex-column" style="border-radius: 14px; overflow: hidden; transition: transform 0.25s ease, box-shadow 0.25s ease;">
              
              <!-- Image Box -->
              <div class="position-relative overflow-hidden" style="height: 220px; background: #e8eee9;">
                <img src="<?php echo e($imgSrc); ?>" alt="<?php echo e($title); ?>" class="w-100 h-100 object-fit-cover" loading="lazy">
                <span class="position-absolute top-0 start-0 m-3 badge bg-dark bg-opacity-75 text-white small px-2 py-1">
                  <?php echo e($loc); ?>

                </span>
                <span class="position-absolute bottom-0 end-0 m-3 badge bg-success text-white small px-2 py-1">
                  <?php echo e($stat); ?>

                </span>
              </div>

              <!-- Body -->
              <div class="p-4 d-flex flex-column justify-content-between flex-grow-1">
                <div>
                  <span class="text-success small fw-semibold text-uppercase tracking-wider d-block mb-1">
                    <?php echo e($tag); ?>

                  </span>
                  <h3 class="h5 fw-bold mb-2" style="color: var(--primary-forest);">
                    <?php echo e($title); ?>

                  </h3>
                  <p class="text-secondary small mb-3" style="line-height: 1.65;">
                    <?php echo e($desc); ?>

                  </p>
                </div>

                <div class="pt-3 border-top border-light-subtle d-flex justify-content-between align-items-center">
                  <?php if(!empty($link)): ?>
                    <?php if(str_starts_with($link, 'http')): ?>
                      <a href="<?php echo e($link); ?>" target="_blank" rel="noopener noreferrer" class="text-success fw-semibold small text-decoration-none">
                        External Feature &nearr;
                      </a>
                    <?php else: ?>
                      <a href="<?php echo e(url($link)); ?>" class="text-success fw-semibold small text-decoration-none">
                        Explore Initiative &rarr;
                      </a>
                    <?php endif; ?>
                  <?php else: ?>
                    <span class="text-muted small"><i class="bi bi-shield-check text-success me-1"></i> Conserve Archive</span>
                  <?php endif; ?>
                  
                  <span class="badge bg-light text-secondary border small">#<?php echo e($cat); ?></span>
                </div>
              </div>

            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

    </div>
  </section>

  <!-- Interactive JavaScript for Filtering -->
  <script>
    document.addEventListener('DOMContentLoaded', function() {
      const filterButtons = document.querySelectorAll('.filter-btn');
      const galleryItems = document.querySelectorAll('.gallery-item');

      filterButtons.forEach(btn => {
        btn.addEventListener('click', function() {
          filterButtons.forEach(b => b.classList.remove('active', 'btn-success', 'text-white'));
          this.classList.add('active', 'btn-success', 'text-white');

          const filter = this.getAttribute('data-filter');

          galleryItems.forEach(item => {
            const cat = item.getAttribute('data-category');
            if (filter === 'all' || cat === filter) {
              item.style.display = 'block';
            } else {
              item.style.display = 'none';
            }
          });
        });
      });
    });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\laravel_project\conserveindia\resources\views\website\gallery.blade.php ENDPATH**/ ?>