<?php $__env->startSection('title', 'Inquiries'); ?>
<?php $__env->startSection('page_heading', 'Contact Form Inquiries'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex align-items-center justify-content-between mb-3">
  <div>
    <h5 class="fw-bold mb-0" style="color: var(--admin-forest);">Contact Form Inquiries</h5>
    <p class="text-muted small mb-0">Messages submitted by visitors through the website contact and partnership forms</p>
  </div>
</div>

<div class="admin-card">
  <div class="table-responsive">
    <table class="table align-middle mb-0">
      <thead class="table-light small text-muted">
        <tr>
          <th>Sender Info</th>
          <th>Subject &amp; Snippet</th>
          <th>Received Date</th>
          <th>Status</th>
          <th class="text-end" style="width: 130px;">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $inquiries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inquiry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr class="<?php echo e(!$inquiry->is_read ? 'table-warning bg-opacity-25' : ''); ?>">
            <td>
              <div class="fw-bold text-dark"><?php echo e($inquiry->name); ?></div>
              <div class="text-muted small">
                <i class="bi bi-envelope"></i> <?php echo e($inquiry->email); ?>

                <?php if($inquiry->phone): ?>
                  &middot; <i class="bi bi-telephone"></i> <?php echo e($inquiry->phone); ?>

                <?php endif; ?>
              </div>
            </td>
            <td>
              <div class="fw-semibold text-dark"><?php echo e($inquiry->subject ?? 'General Inquiry'); ?></div>
              <div class="text-muted small"><?php echo e(Str::limit($inquiry->message, 70)); ?></div>
            </td>
            <td class="small text-muted text-nowrap">
              <?php echo e($inquiry->created_at->format('M d, Y · h:i A')); ?>

            </td>
            <td>
              <?php if($inquiry->is_read): ?>
                <span class="badge bg-light text-muted border">Read</span>
              <?php else: ?>
                <span class="badge bg-danger rounded-pill">Unread</span>
              <?php endif; ?>
            </td>
            <td class="text-end">
              <div class="btn-group btn-group-sm">
                <a href="<?php echo e(route('admin.inquiries.show', $inquiry->id)); ?>" class="btn btn-light border" title="View Message">
                  <i class="bi bi-eye"></i> View
                </a>
                <form action="<?php echo e(route('admin.inquiries.destroy', $inquiry->id)); ?>" method="POST" onsubmit="return confirm('Delete this message?');" class="d-inline">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button type="submit" class="btn btn-light border text-danger" title="Delete">
                    <i class="bi bi-trash"></i>
                  </button>
                </form>
              </div>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr>
            <td colspan="5" class="text-center py-4 text-muted">
              No inquiries received yet.
            </td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php if($inquiries->hasPages()): ?>
    <div class="p-3 border-top">
      <?php echo e($inquiries->links()); ?>

    </div>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\laravel_project\conserveindia\resources\views\admin\inquiries\index.blade.php ENDPATH**/ ?>