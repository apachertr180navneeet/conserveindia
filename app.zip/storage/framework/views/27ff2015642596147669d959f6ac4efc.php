<?php $__env->startSection('title', 'News & Stories'); ?>
<?php $__env->startSection('page_heading', 'News, Stories & Publications'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex align-items-center justify-content-between mb-3">
  <div>
    <h5 class="fw-bold mb-0" style="color: var(--admin-forest);">News &amp; Green Stories</h5>
    <p class="text-muted small mb-0">Publish circular economy updates, artisan interviews, and impact reports</p>
  </div>
  <a href="<?php echo e(route('admin.news.create')); ?>" class="btn btn-admin-forest">
    <i class="bi bi-plus-lg me-1"></i> Post New Article
  </a>
</div>

<div class="admin-card">
  <div class="table-responsive">
    <table class="table align-middle mb-0">
      <thead class="table-light small text-muted">
        <tr>
          <th style="width: 100px;">Photo</th>
          <th>Article Title &amp; Category</th>
          <th>Date</th>
          <th>Status</th>
          <th class="text-end" style="width: 130px;">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td>
              <div class="rounded border overflow-hidden" style="width: 80px; height: 50px;">
                <?php if($item->image): ?>
                  <img src="<?php echo e(asset('website/' . $item->image)); ?>" class="w-100 h-100 object-fit-cover" alt="<?php echo e($item->title); ?>">
                <?php else: ?>
                  <div class="w-100 h-100 bg-light d-flex align-items-center justify-content-center text-muted small">No Img</div>
                <?php endif; ?>
              </div>
            </td>
            <td>
              <span class="badge bg-light text-secondary border small mb-1"><?php echo e($item->category); ?></span>
              <div class="fw-bold text-dark"><?php echo e($item->title); ?></div>
              <div class="text-muted small"><?php echo e(Str::limit($item->summary, 85)); ?></div>
            </td>
            <td class="small text-muted text-nowrap">
              <?php echo e($item->published_date ? $item->published_date->format('M d, Y') : 'Draft'); ?>

            </td>
            <td>
              <?php if($item->is_active): ?>
                <span class="badge bg-success">Published</span>
              <?php else: ?>
                <span class="badge bg-secondary">Draft</span>
              <?php endif; ?>
            </td>
            <td class="text-end">
              <div class="btn-group btn-group-sm">
                <a href="<?php echo e(route('admin.news.edit', $item->id)); ?>" class="btn btn-light border" title="Edit">
                  <i class="bi bi-pencil-square"></i>
                </a>
                <form action="<?php echo e(route('admin.news.destroy', $item->id)); ?>" method="POST" onsubmit="return confirm('Delete this article?');" class="d-inline">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button type="submit" class="btn btn-light border text-danger" title="Delete">
                    <i class="bi bi-trash"></i>
                  </button>
                </form>
              </div>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr>
            <td colspan="5" class="text-center py-4 text-muted">No news articles published yet.</td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\laravel_project\conserveindia\resources\views\admin\news\index.blade.php ENDPATH**/ ?>