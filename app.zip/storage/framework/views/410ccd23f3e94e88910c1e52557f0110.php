<?php $__env->startSection('title', 'Testimonials'); ?>
<?php $__env->startSection('page_heading', 'Partner Testimonials & Endorsements'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex align-items-center justify-content-between mb-3">
  <div>
    <h5 class="fw-bold mb-0" style="color: var(--admin-forest);">Partner Testimonials</h5>
    <p class="text-muted small mb-0">Manage partner endorsements displayed on the homepage</p>
  </div>
  <a href="<?php echo e(route('admin.testimonials.create')); ?>" class="btn btn-admin-forest">
    <i class="bi bi-plus-lg me-1"></i> Add Testimonial
  </a>
</div>

<div class="admin-card">
  <div class="table-responsive">
    <table class="table align-middle mb-0">
      <thead class="table-light small text-muted">
        <tr>
          <th style="width: 70px;">Order</th>
          <th style="width: 100px;">Logo</th>
          <th>Author &amp; Organization</th>
          <th>Quote</th>
          <th>Status</th>
          <th class="text-end" style="width: 130px;">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td class="fw-bold text-muted">#<?php echo e($item->order); ?></td>
            <td>
              <div class="rounded border p-1 bg-white text-center" style="width: 80px; height: 50px;">
                <?php if($item->logo): ?>
                  <img src="<?php echo e(asset('website/' . $item->logo)); ?>" class="w-100 h-100 object-fit-contain" alt="<?php echo e($item->author); ?>">
                <?php else: ?>
                  <span class="text-muted small">No Logo</span>
                <?php endif; ?>
              </div>
            </td>
            <td>
              <div class="fw-bold text-dark"><?php echo e($item->author); ?></div>
              <div class="text-muted small"><?php echo e($item->designation); ?></div>
            </td>
            <td class="small text-muted">
              &ldquo;<?php echo e(Str::limit($item->quote, 95)); ?>&rdquo;
            </td>
            <td>
              <?php if($item->is_active): ?>
                <span class="badge bg-success">Active</span>
              <?php else: ?>
                <span class="badge bg-secondary">Inactive</span>
              <?php endif; ?>
            </td>
            <td class="text-end">
              <div class="btn-group btn-group-sm">
                <a href="<?php echo e(route('admin.testimonials.edit', $item->id)); ?>" class="btn btn-light border" title="Edit">
                  <i class="bi bi-pencil-square"></i>
                </a>
                <form action="<?php echo e(route('admin.testimonials.destroy', $item->id)); ?>" method="POST" onsubmit="return confirm('Delete this testimonial?');" class="d-inline">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button type="submit" class="btn btn-light border text-danger" title="Delete">
                    <i class="bi bi-trash"></i>
                  </button>
                </form>
              </div>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr>
            <td colspan="6" class="text-center py-4 text-muted">No testimonials added yet.</td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\laravel_project\conserveindia\resources\views\admin\testimonials\index.blade.php ENDPATH**/ ?>