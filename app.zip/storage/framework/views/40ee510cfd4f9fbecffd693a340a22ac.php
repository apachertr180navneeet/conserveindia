<?php $__env->startSection('title', 'Hero Sliders'); ?>
<?php $__env->startSection('page_heading', 'Hero Carousel Sliders'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex align-items-center justify-content-between mb-3">
  <div>
    <h5 class="fw-bold mb-0" style="color: var(--admin-forest);">Hero Sliders</h5>
    <p class="text-muted small mb-0">Manage slides shown in the homepage header banner</p>
  </div>
  <a href="<?php echo e(route('admin.sliders.create')); ?>" class="btn btn-admin-forest">
    <i class="bi bi-plus-lg me-1"></i> Add New Slide
  </a>
</div>

<div class="admin-card">
  <div class="table-responsive">
    <table class="table align-middle mb-0">
      <thead class="table-light small text-muted">
        <tr>
          <th style="width: 70px;">Order</th>
          <th style="width: 120px;">Image</th>
          <th>Title &amp; Subtitle</th>
          <th>Buttons</th>
          <th>Status</th>
          <th class="text-end" style="width: 140px;">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td class="fw-bold text-muted">#<?php echo e($slider->order); ?></td>
            <td>
              <div class="rounded border overflow-hidden" style="width: 100px; height: 60px;">
                <img src="<?php echo e(asset('website/' . $slider->image)); ?>" alt="<?php echo e($slider->title); ?>" class="w-100 h-100 object-fit-cover">
              </div>
            </td>
            <td>
              <?php if($slider->tag): ?>
                <span class="badge bg-success bg-opacity-10 text-success small mb-1"><?php echo e($slider->tag); ?></span>
              <?php endif; ?>
              <div class="fw-bold text-dark"><?php echo e($slider->title); ?></div>
              <div class="text-muted small"><?php echo e(Str::limit($slider->subtitle, 85)); ?></div>
            </td>
            <td class="small">
              <?php if($slider->button_text): ?>
                <div><i class="bi bi-link-45deg"></i> <?php echo e($slider->button_text); ?> &rarr; <code><?php echo e($slider->button_link); ?></code></div>
              <?php endif; ?>
              <?php if($slider->secondary_button_text): ?>
                <div class="text-muted"><i class="bi bi-link-45deg"></i> <?php echo e($slider->secondary_button_text); ?> &rarr; <code><?php echo e($slider->secondary_button_link); ?></code></div>
              <?php endif; ?>
            </td>
            <td>
              <?php if($slider->is_active): ?>
                <span class="badge bg-success">Active</span>
              <?php else: ?>
                <span class="badge bg-secondary">Inactive</span>
              <?php endif; ?>
            </td>
            <td class="text-end">
              <div class="btn-group btn-group-sm">
                <a href="<?php echo e(route('admin.sliders.edit', $slider->id)); ?>" class="btn btn-light border" title="Edit">
                  <i class="bi bi-pencil-square"></i>
                </a>
                <form action="<?php echo e(route('admin.sliders.destroy', $slider->id)); ?>" method="POST" onsubmit="return confirm('Delete this slide?');" class="d-inline">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button type="submit" class="btn btn-light border text-danger" title="Delete">
                    <i class="bi bi-trash"></i>
                  </button>
                </form>
              </div>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr>
            <td colspan="6" class="text-center py-4 text-muted">No sliders configured yet.</td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\laravel_project\conserveindia\resources\views\admin\sliders\index.blade.php ENDPATH**/ ?>