<?php $__env->startSection('title', 'View Inquiry'); ?>
<?php $__env->startSection('page_heading', 'Inquiry Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
  <div class="col-lg-8">
    <div class="admin-card">
      <div class="admin-card-header">
        <h6 class="fw-bold mb-0">Message from: <?php echo e($inquiry->name); ?></h6>
        <a href="<?php echo e(route('admin.inquiries.index')); ?>" class="btn btn-sm btn-outline-secondary">Back to Inquiries</a>
      </div>
      <div class="admin-card-body">
        <div class="row g-3 pb-3 mb-3 border-bottom">
          <div class="col-sm-6">
            <span class="text-muted small d-block">Sender Name</span>
            <span class="fw-bold fs-6"><?php echo e($inquiry->name); ?></span>
          </div>
          <div class="col-sm-6">
            <span class="text-muted small d-block">Email Address</span>
            <a href="mailto:<?php echo e($inquiry->email); ?>" class="text-decoration-none fw-semibold">
              <i class="bi bi-envelope"></i> <?php echo e($inquiry->email); ?>

            </a>
          </div>
          <div class="col-sm-6">
            <span class="text-muted small d-block">Phone Number</span>
            <span class="fw-semibold"><?php echo e($inquiry->phone ?? 'Not provided'); ?></span>
          </div>
          <div class="col-sm-6">
            <span class="text-muted small d-block">Received On</span>
            <span class="text-muted"><?php echo e($inquiry->created_at->format('F d, Y · h:i A')); ?></span>
          </div>
        </div>

        <div class="mb-4">
          <span class="text-muted small d-block mb-1">Subject</span>
          <div class="fw-bold fs-5 text-dark"><?php echo e($inquiry->subject ?? 'General Website Inquiry'); ?></div>
        </div>

        <div class="mb-4">
          <span class="text-muted small d-block mb-2">Message Content</span>
          <div class="p-3 bg-light rounded border text-secondary" style="line-height: 1.7; white-space: pre-wrap;"><?php echo e($inquiry->message); ?></div>
        </div>

        <div class="d-flex align-items-center justify-content-between pt-3 border-top">
          <a href="mailto:<?php echo e($inquiry->email); ?>?subject=Re: <?php echo e(rawurlencode($inquiry->subject ?? 'Conserve India Inquiry')); ?>" class="btn btn-admin-forest">
            <i class="bi bi-reply-fill me-1"></i> Reply via Email
          </a>
          <form action="<?php echo e(route('admin.inquiries.destroy', $inquiry->id)); ?>" method="POST" onsubmit="return confirm('Permanently delete this inquiry?');">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-outline-danger btn-sm">
              <i class="bi bi-trash me-1"></i> Delete Inquiry
            </button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\laravel_project\conserveindia\resources\views\admin\inquiries\show.blade.php ENDPATH**/ ?>