<?php $__env->startSection('title', 'Flagship Initiatives'); ?>
<?php $__env->startSection('page_heading', 'Our Work & Initiatives'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex align-items-center justify-content-between mb-3">
  <div>
    <h5 class="fw-bold mb-0" style="color: var(--admin-forest);">Flagship Initiatives</h5>
    <p class="text-muted small mb-0">Manage featured project cards shown across homepage and work sections</p>
  </div>
  <a href="<?php echo e(route('admin.initiatives.create')); ?>" class="btn btn-admin-forest">
    <i class="bi bi-plus-lg me-1"></i> Add Initiative
  </a>
</div>

<div class="admin-card">
  <div class="table-responsive">
    <table class="table align-middle mb-0">
      <thead class="table-light small text-muted">
        <tr>
          <th style="width: 70px;">Order</th>
          <th style="width: 110px;">Image</th>
          <th>Initiative Details</th>
          <th>Link Path</th>
          <th>Status</th>
          <th class="text-end" style="width: 130px;">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $initiatives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td class="fw-bold text-muted">#<?php echo e($item->order); ?></td>
            <td>
              <div class="rounded border overflow-hidden" style="width: 90px; height: 56px;">
                <img src="<?php echo e(asset('website/' . $item->image)); ?>" class="w-100 h-100 object-fit-cover" alt="<?php echo e($item->title); ?>">
              </div>
            </td>
            <td>
              <span class="badge bg-light text-success border border-success-subtle small mb-1"><?php echo e($item->meta); ?></span>
              <div class="fw-bold text-dark"><?php echo e($item->title); ?></div>
              <div class="text-muted small"><?php echo e(Str::limit($item->short_description, 80)); ?></div>
            </td>
            <td class="small"><code><?php echo e($item->link); ?></code></td>
            <td>
              <?php if($item->is_active): ?>
                <span class="badge bg-success">Active</span>
              <?php else: ?>
                <span class="badge bg-secondary">Inactive</span>
              <?php endif; ?>
            </td>
            <td class="text-end">
              <div class="btn-group btn-group-sm">
                <a href="<?php echo e(route('admin.initiatives.edit', $item->id)); ?>" class="btn btn-light border" title="Edit">
                  <i class="bi bi-pencil-square"></i>
                </a>
                <form action="<?php echo e(route('admin.initiatives.destroy', $item->id)); ?>" method="POST" onsubmit="return confirm('Delete this initiative?');" class="d-inline">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button type="submit" class="btn btn-light border text-danger" title="Delete">
                    <i class="bi bi-trash"></i>
                  </button>
                </form>
              </div>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr>
            <td colspan="6" class="text-center py-4 text-muted">No initiatives recorded yet.</td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\laravel_project\conserveindia\resources\views\admin\initiatives\index.blade.php ENDPATH**/ ?>